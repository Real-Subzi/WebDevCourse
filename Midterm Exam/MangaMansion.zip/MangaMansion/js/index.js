window.onload = async () => {
  await showMovies()
}
const BASE_URL = 'https://gist.githubusercontent.com/abdalabaaji/8a4c9f9aabddbab384693f746dfeab46/raw/ea2497811bc355bb737b5d8630a36bee7cbab303/animes.json'

async function showMovies() {
  alert("Delete Me")
}